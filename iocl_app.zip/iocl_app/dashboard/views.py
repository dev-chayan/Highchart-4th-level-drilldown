from django.shortcuts import render
import pandas as pd
import numpy as np
import json
# import requests
# from django.core.files.storage import FileSystemStorage

def file_input(request):
    return render(request,"input_intent.html")







# def file_result1(request):
#     global intents_list, set_of_texts
#     data = {}
#     print(request.method)
#     if request.method == "GET":
#         return render(request, "input_intent.html", data)
#     else:
#         print("ok")
#
#         # print(request.POST)
#
#         csv_file = request.FILES["myfile"]
#         # print(csv_file)
#
#         file = pd.read_excel(csv_file)
#         # file['State'] = [y[0]+'.'+y[1] for x in list(file['State']) for y in x.split()]
#         # new_state_names=[]
#         # for name in file['State']:
#         #     new_state_names.append(name.split(" ")[0][0] + "." + name.split(" ")[1][0] + "." + name.split(" ")[2][0])
#         #
#         # file['State'] = new_state_names
#
#         def series_data(data):
#             state_sales_data = data.groupby('State').sum()['MaterialQuantity']
#
#             state_names = list(state_sales_data.index)
#             state_values = list(np.round(np.array(state_sales_data),1))
#
#             state_drill_data = [{'name': x, 'y': y, 'drilldown': x.replace(" ","")} for x, y in zip(state_names, state_values)]
#             return state_names,state_drill_data
#
#         state_names_all = series_data(file)[0]
#         state_drill_data = series_data(file)[1]
#
#         def drilldown_data(state_names,data) :
#             drilldown_list = []
#
#             for state_name in state_names:
#                 single_state_data = data[data['State'] == state_name]
#                 plant_data = single_state_data.groupby('PlantDescription').sum()['MaterialQuantity']
#                 plant_list = list(plant_data.index)
#                 plant_values = list(np.round(np.array(plant_data),1))
#                 drill_plant_list = [[plant,qty] for plant,qty in zip(plant_list,plant_values)]
#                 drilldown_list.append({'name': state_name,
#                                        'id' : state_name.replace(" ",""),
#                                        'data' : drill_plant_list})
#
#             return drilldown_list
#
#         drilldown_list = drilldown_data(state_names_all,file)
#
#         # print(drilldown_list)
# #################################################################################################
#        ## 1st plot experimentimg data drilldown with legend
#        ## legend = year
#        ## 1st level = state
#        ## 2nd level = plant
#
#         ### yearwise Series data preparation
#         years = file['Year'].unique()
#         print(years)
#         yearwise_series_list = []
#         drillwon_ids = []
#         for index,year in enumerate(years):
#             year_data = file[file['Year'] == year]
#             yearwise_series_data = []
#             year_state_sales_data = year_data.groupby('State').sum()['MaterialQuantity'].reset_index()
#             # print(year_state_sales_data)
#             # print("/n/n")
#
#             #append any state if it is not present in that year
#             for state in state_names_all:
#                 if state not in list(year_state_sales_data['State']):
#                     year_state_sales_data.append({'State' : state,
#                                                   'MaterialQuantity' : 0},ignore_index=True)
#             year_state_sales_data = year_state_sales_data.sort_values(by = 'State')
#             for i in range(year_state_sales_data.shape[0]):
#                 yearwise_series_data.append({'name': year_state_sales_data['State'][i],
#                                              'colorByPoint':'true',
#                                              'y':round(year_state_sales_data['MaterialQuantity'][i],1),
#                                              'drilldown': str(year)+year_state_sales_data['State'][i]})
#                 drillwon_ids.append(str(year)+year_state_sales_data['State'][i])
#             yearwise_series_list.append({'index': index,
#                                          'name': year,
#                                          'turboThreshold': 0,
#                                          'cropThreshold': 'Infinity',
#                                          'data': yearwise_series_data})
#
#         #
#         # print(drillwon_ids)
#
#         ## preparation of drilldown series data for yearwise lengend
#         # need drillwon_ids,
#
#         drilldown_series_data_yearwise = []
#         plantwise_drilldown_ids_plant_name = []
#         for state_drill_id in drillwon_ids:
#             year = state_drill_id[:9]
#             state = state_drill_id[9:]
#             yearwise_state_filtered_data = file[(file['Year'] == year) & (file['State'] == state)]
#             plant_aggregated_data = yearwise_state_filtered_data.groupby('PlantDescription').sum()['MaterialQuantity']
#             plant_list1 = list(plant_aggregated_data.index)
#             plant_values1 = list(np.round(np.array(plant_aggregated_data), 1))
#             # series_plant_list = [{'name': plant, 'y' : qty, 'drillwown': str(year)+state+plant} for plant, qty in zip(plant_list1, plant_values1)]
#             series_plant_list = []
#             for plant, qty in zip(plant_list1, plant_values1):
#                 plant_drillwown_id = year+state+plant
#                 # plant_drillwown_id = plant_drillwown_id
#                 series_plant_list.append({'name': plant, 'y' : qty, 'drilldown': plant_drillwown_id})
#                 plantwise_drilldown_ids_plant_name.append(plant_drillwown_id)
#             drilldown_series_data_yearwise.append({'name': year,
#                                                   'id': state_drill_id,
#                                                   'turboThreshold': 0,
#                                                   'cropThreshold': 'Infinity',
#                                                   'showInLegend': 'true',
#                                                   'data': series_plant_list})
#
#         print(plantwise_drilldown_ids_plant_name)
#         # appending category for each plant based on year and state
#         for plant_drill_id in plantwise_drilldown_ids_plant_name:
#             year = plant_drill_id[:9]
#             state = plant_drill_id[9:12]
#             plant = plant_drill_id[12:]
#             print(year,state,plant)
#             # full_series_category_list = []
#             # for ind,plant in enumerate(plant_list1):
#             yearwise_state_planr_filtered_data = file[(file['Year'] == year) & (file['State'] == state) & (file['PlantDescription'] == plant)]
#             print(yearwise_state_planr_filtered_data.shape)
#             category_aggregated_data = yearwise_state_planr_filtered_data.groupby('MaterialCategory').sum()['MaterialQuantity']
#             category_list = list(category_aggregated_data.index)
#             category_values = list(np.round(np.array(category_aggregated_data), 1))
#             series_category_list = [{'name': category,'id': plant_drill_id+category, 'y': qty, 'type_legend': 'green','color':'green'} for category, qty in zip(category_list, category_values)]
#             # series_category_list = [[category, qty] for category, qty in zip(category_list, category_values)]
#             # series_category_list = []
#             # for j, category, qty in zip(range(len(category_list)), category_list, category_values):
#             #     print("eseche")
#             #     series_category_list.append({ 'name': category,
#             #                                   # 'id': str(i)+str(j),
#             #                                   'y': qty
#             #                                   })
#             #     print('id',str(i)+str(j))
#             # full_series_category_list.append()
#             drilldown_series_data_yearwise.append({'name': year,
#                                                        'id': plant_drill_id,
#                                                        'turboThreshold': 0,
#                                                        'cropThreshold': 'Infinity',
#                                                        'showInLegend': 'true',
#                                                        'data': series_category_list})
#         for i in drilldown_series_data_yearwise:
#             print(i)
#             print("/n")
#
#         return render(request,"product_dashboard.html",{
#                                                         # 'State_cylinder_data_axis' : state_names,
#                                                         # 'State_cylinder_data_values' : state_values,
#                                                         '1st_graph_statewise_drill_data': yearwise_series_list,
#                                                         '1st_graph_drilldown_data': drilldown_series_data_yearwise,
#                                                         '2nd_graph_statewise_drill_data': json.dumps(state_drill_data),
#                                                         '2nd_graph_drilldown_data' : json.dumps(drilldown_list)})

def create_chart_series_objects(file,aggregation_field,roundoff):
            years = file['Year'].unique()
            # print(years)

            # year_qty_agg_data = file.groupby(['Year']).sum()['MaterialQuantity']
            # print(year_qty_agg_data)

            yearwise_series_list = []
            drillwon_ids = []
            
            
            
            colors = ['#84bd04','#0a225c']
            year_state_sales_data = file.groupby('Year').sum()[aggregation_field].reset_index()
            year_state_sales_data = year_state_sales_data.sort_values(by = 'Year')
            print('unique',years)
            for index,year in enumerate(years):
                # year_data = file[file['Year'] == year]
                yearwise_series_data = []
                
                for i in range(year_state_sales_data.shape[0]):
                    
                    if i == index:
                        # year_state_sales_data[aggregation_field][i] = None
                        y_val = None
                    else:
                        y_val = round(year_state_sales_data[aggregation_field][i],roundoff)
                    # print("y_val",y_val)   
                    yearwise_series_data.append({'name': year_state_sales_data['Year'][i],
                                                 'colorByPoint':'true',
                                                 'y':y_val,
                                                 # 'y' : round(year_state_sales_data['MaterialQuantity'][i],1),
                                                 'drilldown': str(year)})
                # drillwon_ids.append(str(year))
                yearwise_series_list.append({'index': index,
                                             'color': colors[index],
                                             
                                             'name': str(year),
                                             'turboThreshold': 0,
                                             'cropThreshold': 'Infinity',
                                             'data': yearwise_series_data})

                drillwon_ids.append(str(year))
            print('drillwon_ids',drillwon_ids)
            for i in yearwise_series_list:
                print(i)
                print("\n\n")
            ## preparation of drilldown series data for yearwise lengend
            # need drillwon_ids,

            drilldown_series_data_yearwise = []
            plantwise_drilldown_ids_plant_name = []
          
            for state_drill_id in drillwon_ids:
                year = state_drill_id
                yearwise_state_filtered_data = file[(file['Year'] == year)]
                plant_aggregated_data = yearwise_state_filtered_data.groupby('State').sum()[aggregation_field]
                plant_list1 = list(plant_aggregated_data.index)
                plant_values1 = list(np.round(np.array(plant_aggregated_data), roundoff))
                # series_plant_list = [{'name': plant, 'y' : qty, 'drillwown': str(year)+state+plant} for plant, qty in zip(plant_list1, plant_values1)]
                series_plant_list = []
                for plant, qty in zip(plant_list1, plant_values1):
                    plant_drillwown_id = str(year)+plant
                    # plant_drillwown_id = plant_drillwown_id
                    series_plant_list.append({'name': plant, 'y' : qty, 'drilldown': plant_drillwown_id})
                    plantwise_drilldown_ids_plant_name.append(plant_drillwown_id)
                drilldown_series_data_yearwise.append({'name': str(year),
                                                      'id': state_drill_id,
                                                      'turboThreshold': 0,
                                                      'cropThreshold': 'Infinity',
                                                      'showInLegend': 'true',
                                                      'data': series_plant_list})

            # print(plantwise_drilldown_ids_plant_name)
            # appending category for each plant based on year and state
            category_drill_down_ids = []
            for plant_drill_id in plantwise_drilldown_ids_plant_name:
                year = plant_drill_id[:9]
                state = plant_drill_id[9:]

                # print(year,state,plant)
                # full_series_category_list = []
                # for ind,plant in enumerate(plant_list1):
                yearwise_state_planr_filtered_data = file[(file['Year'] == year) & (file['State'] == state)]
                # print(yearwise_state_planr_filtered_data.shape)
                category_aggregated_data = yearwise_state_planr_filtered_data.groupby('PlantDescription').sum()[aggregation_field]
                category_list = list(category_aggregated_data.index)
                category_values = list(np.round(np.array(category_aggregated_data), roundoff))
                series_category_list = []
                # series_category_list = [{'name': category,'id': plant_drill_id+category, 'drilldown':plant_drill_id+category, 'y': qty, 'type_legend': 'green','color':'green'} for category, qty in zip(category_list, category_values)]
                for category, qty in zip(category_list, category_values):
                    drilldown_id1 = plant_drill_id+'^^'+category
                    series_category_list.append({'name': category,'id': drilldown_id1, 'drilldown':drilldown_id1, 'y': qty})
                    category_drill_down_ids.append(drilldown_id1)

                drilldown_series_data_yearwise.append({'name': str(year),
                                                           'id': plant_drill_id,
                                                           'turboThreshold': 0,
                                                           'cropThreshold': 'Infinity',
                                                           'showInLegend': 'true',
                                                           'data': series_category_list})

            for category_drill_id in category_drill_down_ids:
                splitted_category_drill_id = category_drill_id.split('^^')
                year = splitted_category_drill_id[0][:9]
                state = splitted_category_drill_id[0][9:]
                plant = splitted_category_drill_id[1]
                # print(year,state,plant)
                # full_series_category_list = []
                # for ind,plant in enumerate(plant_list1):
                yearwise_state_plant_category_filtered_data = file[(file['Year'] == year) & (file['State'] == state) & (file['PlantDescription'] == plant)]
                # print(yearwise_state_planr_filtered_data.shape)
                plant_category_aggregated_data = yearwise_state_plant_category_filtered_data.groupby('MaterialCategory').sum()[
                    aggregation_field]
                category_list1 = list(plant_category_aggregated_data.index)
                category_values1 = list(np.round(np.array(plant_category_aggregated_data), roundoff))
                series_category_list1 = []
                # series_category_list = [{'name': category,'id': plant_drill_id+category, 'drilldown':plant_drill_id+category, 'y': qty, 'type_legend': 'green','color':'green'} for category, qty in zip(category_list, category_values)]
                for category1, qty in zip(category_list1, category_values1):
                    drilldown_id2 = category_drill_id + category1
                    series_category_list1.append(
                        {'name': category1, 'id': drilldown_id2, 'y': qty})

                drilldown_series_data_yearwise.append({'name': str(year),
                                                       'id': category_drill_id,
                                                       'turboThreshold': 0,
                                                       'cropThreshold': 'Infinity',
                                                       'showInLegend': 'true',
                                                       'data': series_category_list1
                                                       })

            return yearwise_series_list,drilldown_series_data_yearwise
        
        



def file_result1(request):
    global intents_list, set_of_texts
    data = {}
    print(request.method)
    if request.method == "GET":
        return render(request, "input_intent.html", data)
    else:
        print("ok")

        # print(request.POST)

        csv_file = request.FILES["myfile"]
        # print(csv_file)

        file = pd.read_excel(csv_file)
        file['MaterialValue'] = file['MaterialValue'].astype(float)
        # print(file.info())
        # file['State'] = [y[0]+'.'+y[1] for x in list(file['State']) for y in x.split()]
        # new_state_names=[]
        # # for name in file['State']:
        # #     new_state_names.append(name.split(" ")[0][0] + "." + name.split(" ")[1][0] + "." + name.split(" ")[2][0])
        # #
        # # file['State'] = new_state_names

        # def series_data(data):
            # state_sales_data = data.groupby('State').sum()['MaterialQuantity']

            # state_names = list(state_sales_data.index)
            # state_values = list(np.round(np.array(state_sales_data),1))

            # state_drill_data = [{'name': x, 'y': y, 'drilldown': x.replace(" ","")} for x, y in zip(state_names, state_values)]
            # return state_names,state_drill_data

        # state_names_all = series_data(file)[0]
        # state_drill_data = series_data(file)[1]

        # def drilldown_data(state_names,data) :
            # drilldown_list = []

            # for state_name in state_names:
                # single_state_data = data[data['State'] == state_name]
                # plant_data = single_state_data.groupby('PlantDescription').sum()['MaterialQuantity']
                # plant_list = list(plant_data.index)
                # plant_values = list(np.round(np.array(plant_data),1))
                # drill_plant_list = [[plant,qty] for plant,qty in zip(plant_list,plant_values)]
                # drilldown_list.append({'name': state_name,
                                       # 'id' : state_name.replace(" ",""),
                                       # 'data' : drill_plant_list})

            # return drilldown_list

        # drilldown_list = drilldown_data(state_names_all,file)

        # print(drilldown_list)
#################################################################################################
       ## 1st plot experimentimg data drilldown with legend
       ## legend = year
       ## 1st level = state
       ## 2nd level = plant

        ### yearwise Series data preparation
        
        
        
        first_graph_qty = create_chart_series_objects(file,'MaterialQuantity',1)
        first_series = first_graph_qty[0]
        first_drilldown_series = first_graph_qty[1]

        second_graph_qty = create_chart_series_objects(file,'MaterialValue',0)
        second_series = second_graph_qty[0]
        second_drilldown_series = second_graph_qty[1]


        # print(second_series)


        return render(request,"product_dashboard.html",{
                                                        # 'State_cylinder_data_axis' : state_names,
                                                        # 'State_cylinder_data_values' : state_values,
                                                        '1st_graph_statewise_drill_data': json.dumps(first_series),
                                                        '1st_graph_drilldown_data': json.dumps(first_drilldown_series),
                                                        '2nd_graph_statewise_drill_data_value': json.dumps(second_series),
                                                        '2nd_graph_drilldown_data_value' : json.dumps(second_drilldown_series)
                                                        # '2nd_graph_statewise_drill_data': json.dumps(state_drill_data),
                                                        # '2nd_graph_drilldown_data' : json.dumps(drilldown_list)
                                                        })


